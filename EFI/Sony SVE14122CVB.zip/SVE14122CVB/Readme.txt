Sony SVE14122CVW Hackintosh

My specification:
    - CPU: i3-3110M
    - GPU: Intel HD Graphics 4000
    - Memory: 6GB DDR3
    - HDD: Western Digital 500GB 7200RPM
    - Wireless: AR9485WEG + AR3012

What's working?:
    - macOS Mojave and macOS Catalina (10.14 - 10.15)
    - Battery Indicator
    - QE/CI
    - Brightness Adjustment
    - Audio, Microphone, Headphones, Webcam
    - USB (Read Note Section)
    - Trackpad and Keyboard
    - HDMI Port
    - CPU Power Management (Read Note Section)
    - Sleep

What's not working?:
    - VGA Port (Never work.)
    - Secure Digital Card

Note Section:
    - You need to add your Wifi (and Bluetooth) based on your hardware before you install macOS
    - After installed macOS, you need to re-generate your SMBIOS and remap USB Port with Hackintool
    - Create your own SSDT-PM.aml by using pika's ssdtPrGen: https://github.com/Piker-Alpha/ssdtPRGen.sh
    - Why don't we use AppleALC? Because of output problem (wait for 30s to 1m to get audio output), so we
    used VoodooHDA. If you patched AppleHDA, please share it to me for adding drivers/kext for better audio!