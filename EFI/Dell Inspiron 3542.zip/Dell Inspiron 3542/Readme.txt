Dell Inspiron 3542
My Specs:
    - CPU: Intel Core i3-4010U
    - GPU: Intel HD Graphics 4400
    - Memory: 8GB DDR3L
    - Wireless/BT: DW1506 (Need to replace because of poor speed Internet)
    - Audio Chipset: ALC255
    - LAN Chipset: RTL81xx

What's working:
    - macOS Base
    - Display (1366x768) with QE/CI
    - Brightness (Can be controlled by pressing Fn + F11/F12)
    - Battery Indicator
    - Sleep 
    - Trackpad (I2C, HID)
    - Ethernet via LAN
    - HDMI with 60Hz or higher with audio
    - Camera
    - Headphones, Microphone (Onboard)
    - Internet with cable
    - USB (2.0 and 3.0)

What's not working:
    - Secure Digital Card (SDCard)

What should I do after installed macOS?:
    - Put EFI Folder to EFS Partition by using Clover Configuration
    - Re-generate SMBIOS: Serial Number, SMUUID, Board-ID and Broad Serial Number
    - Fix USB, HDD-Box, Secure Digital Card (SD Card),... not ejected properly: https://github.com/syscl/Fix-usb-sleep

- Last updated date: 20/8/2021, 9:34 AM