Acer Aspire S3-391 Hackintosh Project

My Specs:
- Core i3 (3rd Generation CPU)
- Intel HD Graphics 4000
- HGST 500GB 5400RPM
- AR9462 with AR3xxx Bluetooth
- ALC296

Whats working:
- macOS Base (Supported 10.13.6 - 10.15.7)
- QE/CI and backlight (can be controlled by pressing Fn+Left/Right)
- Audio
- Microphone and headphones
- USB (2.0 and 3.0)
- Sleep
- Trackpad
- HDMI

What's not working:
- Secure Digital Card (SDCard)

What should I do after installed macOS?:
- Put EFI Folder to EFS Partition by using Clover Configuration
- Re-generate SMBIOS by going SMBIOS Section
- Fix USB, HDD-Box, Secure Digital Card (SD Card),... not ejected properly: https://github.com/syscl/Fix-usb-sleep

- Updated to lastest date: 20/8/2021, 8:38 AM