Dell Inspiron 5448 Hackintosh

My Specification:
- CPU: Intel i5-5200U
- GPU: Intel HD Graphics 5500
- Ram: 4GB DDR3L
- Wireless/Bluetooth: Intel AC 3165
- HDD: Western Digital 500GB

What's working:
- QE/CI and output with HDMI
- Brightness (with key)
- Trackpad and Keyboard
- Sleep and wake
- Camera and USB
- Audio: Headphone and Microphone
- Wireless and bluetooth

Note:
- Add your Wireless (and bluetooth) kext based on your hardware before you install macOS
- Re-Generate your SMBIOS
- Map USB after installed macOS