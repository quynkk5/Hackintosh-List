Dell Inspiron 3521
My Specs:
    - CPU: Intel Core i3-3217U
    - GPU: Intel HD Graphics 4000
    - Memory: 8GB DDR3L
    - Wireless/BT: DW1704 (Need to replace)
    - Audio Chipset: ALC282
    - LAN Chipset: RTL8138/RTL81xx

What's working:
    - macOS Base
    - Display (1366x768) with QE/CI
    - Brightness (Can be controlled by pressing Fn + F11/F12)
    - Battery Indicator
    - Sleep 
    - Trackpad (PS2, Synaptics)
    - HDMI with 60Hz or higher with audio
    - Camera
    - Headphones, Microphone (Onboard)
    - Internet with cable
    - USB (2.0 and 3.0)

What's not working:
    - Secure Digital Card (SDCard)

What should I do after installed macOS?:
    - Put EFI Folder to EFS Partition by using Clover Configuration
    - Re-generate SMBIOS: Serial Number, SMUUID, Board-ID and Broad Serial Number
    - Fix USB, HDD-Box, Secure Digital Card (SD Card),... not ejected properly: https://github.com/syscl/Fix-usb-sleep

- Last updated date: 20/8/2021, 8:47 AM