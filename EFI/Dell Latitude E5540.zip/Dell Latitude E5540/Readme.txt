Dell Latitude E5540
My Specs:
    - Core i3-4010U
    - Intel HD Graphics 4400
    - Ram 12GB DDR3L
    - Intel AC7260
    - SSD Kingston 120GB + HDD HGST 500GB

What's thing you used in this EFI?:
    - Clover R5138 with a set of kexts (Drivers)

What's working:
    - macOS Base
    - Display (1366x768) with QE/CI
    - Brightness (Can be controlled by pressing Fn + up/down)
    - Sleep (avoid pressing Fn+F1 because it'll go to hibernate)
    - Trackpad (PS2, ALPS with 4 Figures)
    - HDMI with 60Hz or higher with audio
    - Camera
    - Audio (ALC292)
    - Headphones, Microphone (Onboard)
    - USB (2.0 and 3.0)

What's not working:
    - VGA Port: Cannot fix, but you can use if you have dedicated GPU and need to disable it via SSDT.

What should I do after installed macOS?:
    - Put EFI Folder to EFS Partition by using Clover Configuration
    - Re-generate SMBIOS: Serial Number, SMUUID, Board-ID and Broad Serial Number
    - Fix USB, HDD-Box, Secure Digital Card (SD Card),... not ejected properly: https://github.com/syscl/Fix-usb-sleep

- Updated to lastest date: 20/8/2021, 2:20 AM