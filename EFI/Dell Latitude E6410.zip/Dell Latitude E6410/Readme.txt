Dell Latitude E6410 Hackintosh
! : EFI for this model is not completed, so you can make an issue for me to
adding more functional to this machine!

My Specs:
    - CPU: i5 - 540M
    - GPU: nVIDIA NVS 3100M
    - Ram: 4GB DDR3
    - SSD: Kingston 120GB
    - HDD (Caddy Bay): HGST 320GB
    - Wireless/BT: Intel Centrino 6235
    - Ethernet: Intel

What's working:
    - ONLY WORK IN macOS Sierra AND macOS High Sierra (10.12 - 10.13.6)
    - GPU Detected 512MB with QE/CI
    - Sleep
    - Audio (Speaker and Microphone)
    - Trackpad and keyboard
    - USB (4 Port, include eSATA Port)
    - Battery Indicator
    - Native Power Management
    - Ethernet Port
    - Firewire Port
    - VGA, DisplayPort

What's not working or Bugs:
    - Brightness Slider in System Preferences (When you press, it'll change brightness in monitor but not change in S.P)
    - SD Card
    - When you restart your computer, it'll turn your screen from black to white, so you need to wait for 10 - 15s for this.