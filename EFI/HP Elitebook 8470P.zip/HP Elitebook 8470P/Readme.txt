HP Elitebook 8470P Hackintosh

My specification:
    - CPU: i5-3340M
    - GPU: Intel HD Graphics 4000 (1600x900, This EFI not support display which have 1366x768!)
    - Ram: 10GB DDR3
    - Hard Disk: SSD Kingston 120GB + HDD HGST 500GB
    - Wireless: Intel Centrino 6305
    - Bluetooth: Broadcom 20702

macOS Supported: 10.13.6 (High Sierra) - 10.15.7 (Catalina)
Bootloader: Clover Revision 5138

What's worked?
    - Base macOS
    - QE/CI with Intel HD Graphics 4000
    - Battery Indicator
    - TouchPad and Keyboard
    - Brightness Adjustment
    - Audio Output and Input, Headphones, Webcam
    - CPU Power Management (Read Note Section)
    - Sleep
    - Internet (LAN/Wifi)
    - Fan Automatic Controlled

What's not worked or tested?
    - VGA Port
    - DisplayPort
    
Note:
    - Insert your wifi and bluetooth kext based on your WF/BLT Hardware
    - Create SSDT-PM.aml (Power Management SSDT) from pika's ssdtPrGen: https://github.com/Piker-Alpha/ssdtPRGen.sh
    - Re-Generate your SMBIOS with MacbookPro10,1 or MacBookPro10,2