Dell Latitude E5550
My Specs:
    - Core i3-5010U
    - Intel HD Graphics 5500
    - Ram 8GB DDR3L
    - Intel AC7265

! : I supported both of bootloader: OpenCore and Clover

What's working:
    - macOS Base
    - Display (1366x768) with QE/CI
    - Brightness (Can be controlled by pressing Fn + F11/F12)
    - Sleep
    - Trackpad (PS2, ALPS with 4 Figures)
    - HDMI with 60Hz or higher with audio
    - Audio
    - Headphones, Microphone (Onboard)
    - USB (2.0 and 3.0)

What's not working:
    - VGA Port: Cannot fix, but you can use if you have dedicated GPU and need to disable it via SSDT.

What should I do after installed macOS?:
    - Put EFI Folder to EFS Partition by using Clover Configuration
    - Re-generate SMBIOS: Serial Number, SMUUID, Board-ID and Broad Serial Number
    - Fix USB, HDD-Box, Secure Digital Card (SD Card),... not ejected properly: https://github.com/syscl/Fix-usb-sleep

- Updated to lastest date: 20/8/2021, 9:10 AM